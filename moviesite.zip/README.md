# Thanks for choosing vidva 
# Version 1.0
# Technology Used "Html CSS Bootstrap Javascript Php and MySQL"
# Free Movie Downloads And Api For Developer Option
# Users Can Request Movie Uploads
# Verified On Google
# Built in 3 months
* =========== Developer Information ============== *
# This Website Was Developed By Folarin Ayobami
# Contact +2348029074972
# Portfolio https://trilo.net.boombetexpert.com.ng/folarinayobami
# This Site Is Not For Sale! Beware
# Part Of AYT (AYOBAMI TECH) Company Projects
# Sponsored By Pawatek Digitals